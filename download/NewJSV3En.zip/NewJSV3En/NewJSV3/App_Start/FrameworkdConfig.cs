﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace JSBase.App_Start
{
    public class FrameworkConfig
    {
        public static void Register()
        {
            APP.Init();
        }
    }
}